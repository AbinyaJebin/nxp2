﻿$url='https://nxp2qa.service-now.com/api/now/table/sc_task'
$apikey = 'HCLTest' #User
$password = 'HCLTestqa@123' #Pass
$global:headers = @{"Authorization" = "Basic "+[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($apikey+":"+$password))}
$number = "TASK0110877"
$Body = @{
    number = "$number"
}
$result = Invoke-RestMethod -Uri $url -Headers $global:headers -Body $Body -ContentType "application/json" 
$sys_id=$result.result.sys_id

### update work notes
$surl="$url/$sys_id"
$wnotes = @{
    
    state= "Closed Complete"
    
}
$Body=$wnotes|ConvertTo-Json
$result = Invoke-RestMethod -Uri $surl -Method Patch -Headers $global:headers -Body $Body -ContentType "application/json" 


